module.exports = [
    {
        username: 'korotov',
        name: 'Vadim Korotov',
        email: 'aabs@mail.com',
        phone: '+375331234567'
    },
    {
        username: 'ivanov',
        name: 'Иван Иванов',
        email: 'sasa21@gmail.com',
        phone: '+375331122334'
    },
    {
        username: 'petrov',
        name: 'Петр Петров',
        email: 'petletbet@gmail.com',
        phone: '+375337152233'
    },
]